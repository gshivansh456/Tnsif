//InterfaceOne declaration
package com.tnsif.dayeight.interfaces.extendinginterfaces;

interface InterfaceOne{  
  void print();  
}  

